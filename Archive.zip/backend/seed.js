const mongoose = require('mongoose');
const User = require('./src/models/User');
const Quiz = require('./src/models/Quiz');
const QuizAttempt = require('./src/models/QuizAttempt');
require('dotenv').config();

// Ensure we use the correct URI. 
// If loaded via 'node backend/seed.js', process.env might be empty if .env is in backend/.env
// We will check both or fallback to a hardcoded string if absolutely necessary, but preferred via env.
const MONGO_URI = process.env.MONGO_URI || 'mongodb://localhost:27017/incharge-incontrol';

const seed = async () => {
  console.log('Connecting to:', MONGO_URI.includes('@') ? 'Atlas Cloud DB' : 'Local DB');
  await mongoose.connect(MONGO_URI);
  console.log('Connected to MongoDB');

  // --- CLEANUP ---
  console.log('⚠️  WIPING DATABASE...');
  await QuizAttempt.deleteMany({});
  await Quiz.deleteMany({});
  // We keep Users to avoid forcing re-login for everyone, OR we can wipe them too if requested. 
  // User requested "start from bigging (beginning)", so let's wipe Users too EXCEPT Admin?
  // Use strictly controlled wipe.
  await User.deleteMany({ email: { $ne: 'admin@example.com' } });
  console.log('✅ Database Wiped (Admin preserved, Quizzes/Attempts cleared)');

  // --- CREATE ADMIN ---
  const adminEmail = 'admin@example.com';
  let admin = await User.findOne({ email: adminEmail });
  if (!admin) {
    admin = await User.create({
      name: 'Admin User',
      email: adminEmail,
      password: 'AdminPassword123!',
      mobile: '9999999999',
      role: 'admin',
      firstLoginRequired: true
    });
    console.log('👤 Admin Created');
  } else {
    console.log('👤 Admin Exists');
  }

  // --- CREATE QUIZ ---
  const today = new Date().setHours(0, 0, 0, 0);

  await Quiz.create({
    title: 'Leadership Assessment (Golden Copy)',
    description: 'Find out if you are In-Charge or In-Control.',
    isActive: true,
    activeDate: today,
    generatedBy: 'MANUAL',
    status: 'ACTIVE',
    questions: [
      {
        questionText: 'When a team member misses a deadline, I:',
        options: [
          { text: 'Take over their work to ensure it gets done.', answerType: 'In-Charge' },
          { text: 'Ask them what support they need to finish.', answerType: 'In-Control' },
          { text: 'Reprimand them for the delay.', answerType: 'In-Charge' },
          { text: 'Adjust the schedule to accommodate.', answerType: 'In-Control' }
        ]
      },
      {
        questionText: 'In a meeting, silence makes me feel:',
        options: [
          { text: 'Anxious, I must fill the void.', answerType: 'In-Charge' },
          { text: 'Comfortable, allowing others to think.', answerType: 'In-Control' },
          { text: 'Impated, I want to move on.', answerType: 'In-Charge' },
          { text: 'Curious about what will emerge.', answerType: 'In-Control' }
        ]
      },
      {
        questionText: 'My approach to feedback is:',
        options: [
          { text: 'Direct and often unsolicited.', answerType: 'In-Charge' },
          { text: 'Asked for and given constructively.', answerType: 'In-Control' },
          { text: 'Brutal honesty is key.', answerType: 'In-Charge' },
          { text: 'Focus on growth and learning.', answerType: 'In-Control' }
        ]
      },
      {
        questionText: 'I view delegation as:',
        options: [
          { text: 'Losing control of quality.', answerType: 'In-Charge' },
          { text: 'Empowering others to lead.', answerType: 'In-Control' },
          { text: 'A necessary evil.', answerType: 'In-Charge' },
          { text: 'A way to scale impact.', answerType: 'In-Control' }
        ]
      },
      {
        questionText: 'When plans change, I:',
        options: [
          { text: 'Get frustrated and resist.', answerType: 'In-Charge' },
          { text: 'Adapt and find new opportunities.', answerType: 'In-Control' },
          { text: 'Try to force the original plan.', answerType: 'In-Charge' },
          { text: 'Pivot quickly and calmly.', answerType: 'In-Control' }
        ]
      }
    ]
  });
  console.log('📝 New Schema-Compliant Quiz Created');

  console.log('✨ SEEDING COMPLETE');
  process.exit();
};

seed().catch(err => {
  console.error(err);
  process.exit(1);
});
