import React, { createContext, useContext, useState, useEffect } from 'react';
import axios from 'axios';
import API_BASE_URL from '../config/apiConfig';

const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  // Set default axios config with credentials
  useEffect(() => {
    axios.defaults.withCredentials = true;
  }, []);

  const checkAuth = async () => {
    try {
      const res = await axios.get(`${API_BASE_URL}/auth/me`);
      setUser(res.data.user);
    } catch (err) {
      setUser(null);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    checkAuth();
  }, []);

  const login = async (email, password) => {
    console.log('AuthContext: Attempting login for', email);
    try {
      // Login sets the cookie
      const res = await axios.post(`${API_BASE_URL}/auth/login`, { email, password });
      console.log('AuthContext: Login response', res.data);
      setUser(res.data.user);
      return res.data.user;
    } catch (error) {
      console.error('AuthContext: Login failed', error);
      throw error;
    }
  };

  const logout = async () => {
    try {
      await axios.post(`${API_BASE_URL}/auth/logout`);
    } catch (e) {
      console.error("Logout failed", e);
    }
    setUser(null);
    // Reload to clear state/cache if necessary
    window.location.href = '/login';
  };

  return (
    <AuthContext.Provider value={{ user, login, logout, loading, setUser }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
