import React from 'react';
import { motion } from 'framer-motion';

const RocketAnimation = ({ positionY }) => {
    return (
        <div className="fixed inset-0 w-full h-full overflow-hidden bg-[#050B14] -z-10">

            {/* Deep Space Background & Stars */}
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-[#1B2735] via-[#090A0F] to-[#000000]" />
            <div className="absolute inset-0 opacity-70">
                <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-20 brightness-100 contrast-150 mix-blend-overlay"></div>
                {Array.from({ length: 2500 }).map((_, i) => (
                    <motion.div
                        key={i}
                        className="absolute bg-white rounded-full"
                        initial={{
                            x: Math.random() * window.innerWidth,
                            y: Math.random() * window.innerHeight,
                            opacity: Math.random(),
                            scale: Math.random() * 0.5 + 0.2
                        }}
                        animate={{
                            opacity: [0.2, 1, 0.2],
                            y: [null, Math.random() * window.innerHeight + 100] // Move down to simulate upward motion
                        }}
                        transition={{
                            opacity: { duration: Math.random() * 3 + 2, repeat: Infinity, delay: Math.random() * 5 },
                            y: { duration: Math.random() * 10 + 10, repeat: Infinity, ease: "linear" }
                        }}
                        style={{ width: Math.random() * 2, height: Math.random() * 2 }}
                    />
                ))}
            </div>

            {/* Realistic Solar System (Alive) */}
            <div className="absolute inset-0 pointer-events-none">
                {/* Sun-like glow in corner */}
                <div className="absolute -top-[10%] -left-[10%] w-[50vh] h-[50vh] bg-orange-500/10 rounded-full blur-[100px] pointer-events-none" />

                {/* Planet 1: Gas Giant Theme */}
                <motion.div
                    className="absolute top-[15%] left-[10%] w-32 h-32 md:w-48 md:h-48 rounded-full shadow-[inset_-20px_-20px_50px_rgba(0,0,0,0.8)] z-0"
                    style={{
                        background: 'radial-gradient(circle at 30% 30%, #d97706, #92400e, #451a03)',
                        boxShadow: '0 0 60px -20px rgba(217, 119, 6, 0.3), inset -10px -10px 40px rgba(0,0,0,0.8)'
                    }}
                    animate={{
                        y: [0, -20, 0],
                        rotate: 360
                    }}
                    transition={{
                        y: { duration: 20, repeat: Infinity, ease: "easeInOut" },
                        rotate: { duration: 200, repeat: Infinity, ease: "linear" }
                    }}
                >
                    {/* Ring */}
                    <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[160%] h-[40%] rounded-[50%] border-[2px] border-orange-200/20 rotate-[-15deg] shadow-[0_0_20px_rgba(255,255,255,0.1)]"></div>
                </motion.div>

                {/* Planet 2: Icy Blue World */}
                <motion.div
                    className="absolute top-[60%] right-[15%] w-20 h-20 md:w-32 md:h-32 rounded-full z-0"
                    style={{
                        background: 'radial-gradient(circle at 30% 30%, #67e8f9, #0e7490, #164e63)',
                        boxShadow: '0 0 40px -10px rgba(103, 232, 249, 0.4), inset -10px -10px 30px rgba(0,0,0,0.9)'
                    }}
                    animate={{
                        y: [0, 30, 0],
                        x: [0, -10, 0]
                    }}
                    transition={{ duration: 25, repeat: Infinity, ease: "easeInOut" }}
                />

                {/* Planet 3: Small Rocky Moon */}
                <motion.div
                    className="absolute bottom-[10%] left-[20%] w-12 h-12 md:w-20 md:h-20 rounded-full z-0"
                    style={{
                        background: 'radial-gradient(circle at 30% 30%, #a8a29e, #57534e, #292524)',
                        boxShadow: 'inset -5px -5px 15px rgba(0,0,0,0.9)'
                    }}
                    animate={{
                        y: [0, -15, 0],
                    }}
                    transition={{ duration: 18, repeat: Infinity, ease: "easeInOut" }}
                />
            </div>

            {/* Dynamic Rocket Container */}
            <motion.div
                className="absolute right-[5%] md:right-[15%] w-32 h-32 flex flex-col items-center justify-center z-50 origin-center"
                initial={{ bottom: '50%' }}
                animate={{
                    bottom: `${50 + (positionY || 0)}%`, // Dynamic position: 50% base + offset
                    y: [0, 10, -10, 0], // Gentle hover on top of movement
                }}
                transition={{
                    bottom: { duration: 1.5, ease: "easeInOut" }, // Smooth transitions between positions
                    y: { duration: 4, repeat: Infinity, ease: "easeInOut" }
                }}
            >
                {/* Realistic Rocket SVG */}
                <div className="relative w-full h-full drop-shadow-[0_10px_20px_rgba(0,0,0,0.5)] flex flex-col items-center">
                    <svg viewBox="0 0 100 200" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-20 h-40">
                        <defs>
                            <linearGradient id="bodyGrad" x1="0" y1="0" x2="1" y2="0">
                                <stop offset="0%" stopColor="#e2e8f0" />
                                <stop offset="40%" stopColor="#f8fafc" />
                                <stop offset="100%" stopColor="#94a3b8" />
                            </linearGradient>
                            <linearGradient id="windowGrad" x1="0" y1="0" x2="1" y2="1">
                                <stop offset="0%" stopColor="#38bdf8" />
                                <stop offset="100%" stopColor="#0284c7" />
                            </linearGradient>
                            <filter id="glow">
                                <feGaussianBlur stdDeviation="2.5" result="coloredBlur" />
                                <feMerge>
                                    <feMergeNode in="coloredBlur" />
                                    <feMergeNode in="SourceGraphic" />
                                </feMerge>
                            </filter>
                        </defs>

                        {/* Fins - 3D Perspective */}
                        <path d="M20 140 L-10 190 L30 180 L20 140 Z" fill="#dc2626" stroke="#991b1b" strokeWidth="2" />
                        <path d="M80 140 L110 190 L70 180 L80 140 Z" fill="#dc2626" stroke="#991b1b" strokeWidth="2" />
                        <path d="M50 140 L50 190" stroke="#dc2626" strokeWidth="12" strokeLinecap="round" />

                        {/* Fuselage - Shading for roundness */}
                        <path d="M50 0 C20 0 20 60 20 160 L80 160 C80 60 80 0 50 0" fill="url(#bodyGrad)" stroke="#64748B" strokeWidth="1" />

                        {/* Window - Shiny */}
                        <circle cx="50" cy="60" r="14" fill="#334155" stroke="#475569" strokeWidth="3" />
                        <circle cx="50" cy="60" r="11" fill="url(#windowGrad)" filter="url(#glow)" />
                        <circle cx="47" cy="57" r="3" fill="white" opacity="0.8" />

                        {/* Decals/Seams */}
                        <path d="M20 110 H80" stroke="#cbd5e1" strokeWidth="1" opacity="0.5" />
                        <path d="M20 40 H80" stroke="#cbd5e1" strokeWidth="1" opacity="0.5" />
                    </svg>

                    {/* Engine Flames - Static idle */}
                    <div className="absolute top-[80%] left-1/2 -translate-x-1/2 w-full flex justify-center -z-10">
                        {/* Core */}
                        <motion.div
                            className="w-4 bg-white rounded-b-full blur-[2px]"
                            animate={{ height: [40, 50, 40] }}
                            transition={{ duration: 0.2, repeat: Infinity }}
                        />
                        {/* Middle */}
                        <motion.div
                            className="absolute top-0 w-8 bg-gradient-to-t from-transparent via-yellow-400 to-orange-500 rounded-b-full blur-[4px]"
                            animate={{ height: [60, 80, 60] }}
                            transition={{ duration: 0.3, repeat: Infinity, delay: 0.02 }}
                        />
                    </div>
                </div>
            </motion.div>

        </div>
    );
};

export default RocketAnimation;
