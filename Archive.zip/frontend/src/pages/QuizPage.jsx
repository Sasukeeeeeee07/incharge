import React, { useState, useEffect } from 'react';
import axios from 'axios';
import API_BASE_URL from '../config/apiConfig';
// Ladder component removed as replaced by RocketAnimation
import RocketAnimation from '../components/RocketAnimation';
import QuizHistory from '../components/QuizHistory';
import Speedometer from '../components/Speedometer';
import QuizResultView from '../components/QuizResultView';
import { motion, AnimatePresence } from 'framer-motion';
import { useAuth } from '../context/AuthContext';
import { useNavigate } from 'react-router-dom';
import { LogOut, UserCircle, History, PlayCircle, Calendar, ChevronRight } from 'lucide-react';

const useWindowSize = () => {
  const [windowSize, setWindowSize] = useState({
    width: window.innerWidth,
    height: window.innerHeight,
  });

  useEffect(() => {
    const handleResize = () => {
      setWindowSize({
        width: window.innerWidth,
        height: window.innerHeight,
      });
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  return windowSize;
};

const QuizPage = () => {
  const { logout, user } = useAuth();
  const navigate = useNavigate();
  const { width } = useWindowSize();
  const isMobile = width < 1024;

  const [quiz, setQuiz] = useState(null);
  const [selectedLang, setSelectedLang] = useState(null);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [responses, setResponses] = useState([]);
  const [completed, setCompleted] = useState(false);
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [showDetails, setShowDetails] = useState(false);
  const [rocketPosition, setRocketPosition] = useState(0);

  // Default to 'take-quiz' for a fresh experience
  const [view, setView] = useState('take-quiz');
  const [history, setHistory] = useState([]);
  const [selectedHistoryQuiz, setSelectedHistoryQuiz] = useState(null);

  const languageLabels = {
    english: 'English',
    hindi: 'Hindi',
    gujarati: 'Gujarati',
    malayalam: 'Malayalam'
  };

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  // Persist state to sessionStorage
  // Save progress whenever key state changes
  useEffect(() => {
    if (quiz && !completed && responses.length > 0) {
      saveProgress();
    }
  }, [responses, currentQuestionIndex, selectedLang]);

  const saveProgress = async () => {
    try {
      await axios.put(`${API_BASE_URL}/quiz/progress`, {
        quizId: quiz._id,
        responses,
        currentQuestionIndex,
        language: selectedLang
      });
    } catch (err) {
      console.error('Failed to save progress', err);
    }
  };

  useEffect(() => {
    fetchInitialData();
  }, []);

  const fetchInitialData = async () => {
    setLoading(true);
    try {
      // Parallel fetch today's quiz and history
      const [quizRes, historyRes] = await Promise.all([
        axios.get(`${API_BASE_URL}/quiz/active`).catch(err => ({ status: 404 })),
        axios.get(`${API_BASE_URL}/quiz/history`).catch(err => ({ data: [] }))
      ]);

      setHistory(historyRes.data || []);

      if (quizRes.status === 200) {
        const { quiz: quizData, alreadyAttempted, attempt } = quizRes.data;
        setQuiz(quizData);

        if (alreadyAttempted) {
          // Completed previously
          setResult(attempt);
          setCompleted(true);
          setResponses(attempt.responses);
          setView('take-quiz'); // Show card with "View Results"
        } else if (attempt && attempt.status === 'started') {
          // Resuming an in-progress quiz
          setView('quiz');
          setResponses(attempt.responses || []);
          setCurrentQuestionIndex(attempt.currentQuestionIndex || 0);
          setSelectedLang(attempt.language || 'english');
        } else {
          // New active quiz, never started
          setView('take-quiz');
          setSelectedLang(null);
          setCurrentQuestionIndex(0);
          setResponses([]);
        }
      } else {
        // No quiz for today
        setView('history');
      }
    } catch (err) {
      setError(err.response?.data?.error || 'Failed to initialize');
    } finally {
      setLoading(false);
    }
  };

  const fetchHistory = async () => {
    try {
      const res = await axios.get(`${API_BASE_URL}/quiz/history`);
      setHistory(res.data);
    } catch (err) {
      console.error('Failed to fetch history', err);
    }
  };



  const handleAnswer = (answerType) => {
    const langKey = selectedLang?.toLowerCase();
    const questions = (quiz.content && langKey && quiz.content[langKey])
      ? quiz.content[langKey].questions
      : (quiz.questions || []);

    if (questions.length === 0 || !questions[currentQuestionIndex]) return;

    // Prevent duplicate/multiple clicks handling
    const questionId = questions[currentQuestionIndex]._id;

    // Check if we already have a response for this question (to avoid duplicates if double clicked)
    const existingResponseIndex = responses.findIndex(r => r.questionId === questionId);

    let newResponses;
    if (existingResponseIndex >= 0) {
      newResponses = [...responses];
      newResponses[existingResponseIndex] = { questionId, answerType };
    } else {
      newResponses = [...responses, { questionId, answerType }];
    }

    setResponses(newResponses);

    // Calculate dynamic rocket position based on new responses
    // In-Charge (+10%), In-Control (-5%)
    // Base is 0 (10% bottom)
    // Max is 80 (90% top)
    let newPos = 0;
    newResponses.forEach(r => {
      if (r.answerType === 'In-Charge') newPos += 10;
      else if (r.answerType === 'In-Control') newPos -= 5;
    });
    // Clamp between 0 and 80
    newPos = Math.max(0, Math.min(80, newPos));
    setRocketPosition(newPos);

    if (currentQuestionIndex < questions.length - 1) {
      setCurrentQuestionIndex(prev => prev + 1);
    } else {
      submitQuiz(newResponses);
    }
  };

  const submitQuiz = async (finalResponses) => {
    try {
      const res = await axios.post(`${API_BASE_URL}/quiz/submit`, {
        quizId: quiz._id,
        responses: finalResponses,
        language: selectedLang
      });
      setResult(res.data);
      setCompleted(true);
      setView('result');
      fetchHistory(); // Refresh history after submission
    } catch (err) {
      setError('Failed to submit quiz');
    }
  };

  const handleSelectHistoryQuiz = (attempt) => {
    setSelectedHistoryQuiz(attempt);
    setShowDetails(false); // Start with speedometer view
    setView('history-detail');
  };

  const renderNavbar = () => (
    <header className="px-4 md:px-10 py-3 md:py-5 flex justify-between items-center border-b border-blue-200/10 bg-blue-900/50 backdrop-blur-md sticky top-0 z-40">
      <div
        className="cursor-pointer flex items-center"
        onClick={() => {
          if (quiz) setView('take-quiz');
          else setView('history');
        }}
      >
        <img
          src="/smmart_Logo.png"
          alt="Smmart Logo"
          className="h-8 md:h-12 w-auto object-contain transition-transform hover:scale-105"
        />
      </div>


      <div className="flex items-center gap-2 md:gap-5">
        <span className="text-text-secondary hidden lg:inline">Welcome, {user?.name}</span>

        {quiz && (
          <button
            onClick={() => setView('take-quiz')}
            className={`flex items-center gap-2 px-3 py-5 rounded-lg transition-colors ${view === 'take-quiz' || (view === 'quiz' && !completed) ? 'bg-accent-primary/20 text-accent-primary' : 'text-text-secondary hover:text-white hover:bg-white/5'}`}
          >
            <PlayCircle size={18} /> <span className="hidden sm:inline">Take Quiz</span>
          </button>
        )}

        <button
          onClick={() => setView('history')}
          className={`flex items-center gap-2 px-3 py-5 rounded-lg transition-colors ${view === 'history' || view === 'history-detail' ? 'bg-accent-primary/20 text-accent-primary' : 'text-text-secondary hover:text-white hover:bg-white/5'}`}
        >
          <History size={18} /> <span className="hidden sm:inline">Quiz History</span>
        </button>

        <button onClick={() => navigate('/profile')} className="flex items-center gap-2 px-3 py-5 rounded-lg transition-colors text-text-secondary hover:text-white hover:bg-white/5">
          <UserCircle size={18} /> <span className="hidden sm:inline">Profile</span>
        </button>

        <button onClick={handleLogout} className="flex items-center gap-2 px-3 py-5 rounded-lg transition-colors text-text-secondary hover:text-white hover:bg-red-900">
          <LogOut size={18} /> <span className="hidden sm:inline">Logout</span>
        </button>
      </div>
    </header>
  );

  if (loading) return (
    <div className="min-h-screen bg-bg-primary flex items-center justify-center">
      <div className="text-center text-text-secondary animate-pulse">Loading Your Journey...</div>
    </div>
  );

  if (error) return (
    <div className="min-h-screen flex flex-col items-center justify-center p-10 bg-bg-primary">
      <div className="glass-card p-10 text-center max-w-md">
        <p className="text-error mb-6 text-lg font-medium">{error}</p>
        <button onClick={handleLogout} className="btn-secondary w-full">Logout</button>
      </div>
    </div>
  );

  // Language Selection Screen
  if (view === 'quiz' && !selectedLang) {
    return (
      <div className="min-h-screen flex flex-col bg-bg-primary">
        {renderNavbar()}
        <div className="flex-1 flex flex-col items-center justify-center p-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="glass-card p-12 text-center max-w-2xl w-full"
          >
            <h1 className="text-4xl font-bold mb-4">Choose Your Language</h1>
            <p className="text-text-secondary mb-10">Select a language to start the daily quiz</p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {quiz.languages.map(lang => (
                <button
                  key={lang}
                  onClick={() => {
                    setSelectedLang(lang);
                  }}
                  className="p-6 rounded-2xl border border-white/10 bg-white/5 hover:bg-accent-primary/10 hover:border-accent-primary/50 transition-all text-xl font-semibold active:scale-[0.98]"
                >
                  {languageLabels[lang] || lang}
                </button>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    );
  }

  return (
    <div className="h-screen flex flex-col overflow-hidden relative">
      {/* Full Screen Rocket Background */}
      {view === 'quiz' && (
        <RocketAnimation positionY={rocketPosition} />
      )}

      {renderNavbar()}

      <main className="flex-1 p-4 md:p-6 lg:pt-8 flex flex-col items-center max-w-7xl mx-auto w-full overflow-hidden justify-start">

        {view === 'take-quiz' && quiz && (
          <div className="w-full">
            <h3 className="text-xl font-bold mb-6 text-blue-500 uppercase tracking-widest">Today's Quiz</h3>
            <div className="flex flex-col md:flex-row pb-6 gap-6">
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                onClick={() => {
                  if (completed) {
                    setView('result');
                    return;
                  }

                  // Always go to quiz view without pre-selecting language
                  // This ensures the language selection screen is shown first
                  setView('quiz');
                }}
                className="w-full md:max-w-[400px] glass-card p-8 cursor-pointer hover:border-blue-500/50 transition-all flex flex-col justify-between group relative overflow-hidden"
              >

                <div className="flex justify-between items-start mb-6">
                  <div className="flex items-center gap-2 text-text-secondary text-sm">
                    <Calendar size={14} />
                    {new Date().toLocaleDateString()}
                  </div>
                  <div className="px-3 py-1 rounded-full text-xs font-bold uppercase tracking-tighter bg-blue-500/20 text-blue-400">
                    Active
                  </div>
                </div>

                <h4 className="text-2xl font-bold mb-6 group-hover:text-blue-400 transition-colors">
                  {quiz.title || "Daily Assessment"}
                </h4>

                <div className="flex justify-between items-center mt-4">
                  <span className="text-xs text-text-secondary uppercase font-bold tracking-widest">
                    {completed ? 'View Results' : 'Start Now'}
                  </span>
                  <div className="flex items-center gap-2 text-blue-500 group-hover:translate-x-2 transition-transform font-bold">
                    <span>{completed ? 'VIEW' : 'GO'}</span>
                    <ChevronRight size={20} />
                  </div>
                </div>
              </motion.div>
            </div>
          </div>
        )}

        {view === 'history' && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="w-full flex-1 overflow-y-auto mt-4 px-2"
          >
            <QuizHistory history={history} onSelectQuiz={handleSelectHistoryQuiz} />
          </motion.div>
        )}

        {view === 'history-detail' && selectedHistoryQuiz && (
          <div className="w-full flex-1 flex flex-col items-center overflow-hidden relative">
            <div className="absolute top-0 left-0 z-10">
              <button
                onClick={() => setView('history')}
                className="text-orange-500 hover:bg-orange-500/10 px-4 py-2 rounded-lg flex items-center gap-2 text-sm transition-colors"
              >
                &larr; Back to History
              </button>
            </div>
            <div className="w-full flex-1 flex flex-col items-center pt-14 lg:pt-0">
              <QuizResultView
                result={{ result: selectedHistoryQuiz.result }}
                responses={selectedHistoryQuiz.responses}
                quizData={{
                  content: selectedHistoryQuiz.quizContent,
                  questions: selectedHistoryQuiz.quizQuestions
                }}
                selectedLang={selectedHistoryQuiz.language || Object.keys(selectedHistoryQuiz.quizContent || {})[0] || 'english'}
                showDetails={showDetails}
                setShowDetails={setShowDetails}
                hideToggle={false}
                totalSteps={0}
                currentStep={0}
              />
            </div>
          </div>
        )}

        {view === 'result' && result && (
          <QuizResultView
            result={result}
            responses={responses}
            quizData={quiz}
            selectedLang={selectedLang}
            showDetails={showDetails}
            setShowDetails={setShowDetails}
            currentStep={0}
            totalSteps={0}
          />
        )}

        {view === 'quiz' && quiz && (
          <div className="w-full flex justify-center mt-4 relative z-10">
            <div className="flex flex-col justify-center max-w-2xl mx-auto w-full">
              <AnimatePresence mode="wait">
                {/* ... existing question rendering ... */}
                {(() => {
                  const langKey = selectedLang?.toLowerCase();
                  const questions = (quiz.content && langKey && quiz.content[langKey])
                    ? quiz.content[langKey].questions
                    : (quiz.questions || []);
                  const currentQuestion = questions[currentQuestionIndex];

                  if (!currentQuestion) {
                    return (
                      <div className="glass-card p-12 text-center w-full">
                        <p className="text-text-secondary mb-4">Questions could not be loaded. Please ensure a language is selected.</p>
                        <button onClick={() => { setView('quiz'); setSelectedLang(null); }} className="btn-secondary">Back to Language Selection</button>
                      </div>
                    );
                  }

                  return (
                    <motion.div
                      key={currentQuestionIndex}
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: -20 }}
                      className="glass-card p-8 md:p-12 relative overflow-hidden"
                    >
                      <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-accent-primary to-accent-secondary" />
                      <p className="text-accent-primary font-bold mb-4 tracking-wider text-sm uppercase">
                        Question {currentQuestionIndex + 1} of {questions.length}
                      </p>
                      <h2 className="text-2xl md:text-3xl font-bold mb-10 leading-tight">{currentQuestion.questionText}</h2>
                      <div className="flex flex-col gap-4">
                        {currentQuestion.options.map((option, idx) => (
                          <button
                            key={idx}
                            className="group p-5 rounded-xl border border-glass-border bg-bg-secondary/50 text-left hover:border-accent-primary/10 hover:border-accent-primary/50 transition-all duration-200 active:scale-[0.99]"
                            onClick={() => handleAnswer(option.answerType)}
                          >
                            <span className="font-medium text-lg text-text-primary group-hover:text-white transition-colors">{option.text}</span>
                          </button>
                        ))}
                      </div>
                    </motion.div>
                  );
                })()}
              </AnimatePresence>
            </div>
          </div>
        )}

        {view === 'quiz' && !quiz && (
          <div className="flex-1 flex flex-col items-center justify-center text-center">
            <h2 className="text-3xl font-bold mb-4">No Quiz for Today</h2>
            <p className="text-text-secondary mb-8">Come back tomorrow for a new challenge!</p>
            <button onClick={() => setView('history')} className="btn-primary">View My History</button>
          </div>
        )}
      </main>
    </div>
  );
};

export default QuizPage;

